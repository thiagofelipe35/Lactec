﻿using HistoricoClimatologico.Database;

namespace HistoricoClimatologico.Interfaces.Repository
{
    public interface ICidadeRepository : IBaseRepository<Cidade>
    {
    }
}
