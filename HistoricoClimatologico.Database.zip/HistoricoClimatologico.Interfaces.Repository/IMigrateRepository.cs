﻿using HistoricoClimatologico.Database;

namespace HistoricoClimatologico.Interfaces.Repository
{
    public interface IMigrateRepository
    {
        void Migrate();
    }
}
