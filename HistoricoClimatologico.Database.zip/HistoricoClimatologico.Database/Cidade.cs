﻿namespace HistoricoClimatologico.Database
{
    public class Cidade : BaseEntity
    {
        public string Codigo { get; set; }
        public string Nome { get; set; }
    }
}
