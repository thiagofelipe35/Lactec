﻿using HistoricoClimatologico.Database;
using HistoricoClimatologico.Interfaces.Repository;

namespace HistoricoClimatologico.Repository
{
    public class CidadeRepository : BaseRepository<Cidade>, ICidadeRepository
    {
    }
}
